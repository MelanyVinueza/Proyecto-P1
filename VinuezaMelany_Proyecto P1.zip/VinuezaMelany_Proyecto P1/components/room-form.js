class RoomForm extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        this.render();
        this.shadowRoot.querySelector('form').addEventListener('submit', (e) => this.handleSubmit(e));
    }

    async handleSubmit(event) {
        event.preventDefault();

        const tipo = this.shadowRoot.querySelector('#tipo').value.trim();
        const precio_noche = this.shadowRoot.querySelector('#precio').value.trim();

        if (!tipo || !precio_noche) {
            alert('Todos los campos son obligatorios.');
            return;
        }

        const roomData = { tipo, precio_noche: parseFloat(precio_noche) };

        try {
            const method = this.getAttribute('data-id') ? 'PUT' : 'POST';
            const url = this.getAttribute('data-id')
                ? `http://localhost:3000/habitaciones/${this.getAttribute('data-id')}`
                : 'http://localhost:3000/habitaciones/';

            const response = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(roomData),
            });

            if (response.ok) {
                alert(`Habitación ${method === 'POST' ? 'registrada' : 'actualizada'} exitosamente.`);
                window.location.href = '/listar-habitaciones.html'; // Redirigir a la lista
            } else {
                alert('Error al guardar la habitación.');
            }
        } catch (error) {
            console.error('Error al guardar habitación:', error);
        }
    }

    render() {
        this.shadowRoot.innerHTML = `
            <style>
                form {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    max-width: 400px;
                    margin: 40px auto;
                    padding: 20px;
                    background-color: #f9f9f9;
                    border: 1px solid #ccc;
                    border-radius: 8px;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }
                h2 {
                    text-align: center;
                    color: #333;
                    font-size: 24px;
                    margin-bottom: 20px;
                }
                input {
                    width: 100%;
                    padding: 12px;
                    margin-bottom: 20px;
                    font-size: 16px;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                    box-sizing: border-box;
                }
                button {
                    width: 100%;
                    padding: 12px;
                    font-size: 16px;
                    color: white;
                    background-color: #007BFF;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    transition: background-color 0.3s;
                }
                button:hover {
                    background-color: #0056b3;
                }
                button:disabled {
                    background-color: #ccc;
                    cursor: not-allowed;
                }
            </style>
            <h2>${this.getAttribute('data-id') ? 'Actualizar Habitación' : 'Registrar Habitación'}</h2>
            <form>
                <input type="text" id="tipo" placeholder="Tipo de habitación" required />
                <input type="number" id="precio" placeholder="Precio por noche" required />
                <button type="submit">${this.getAttribute('data-id') ? 'Actualizar' : 'Registrar'}</button>
            </form>
        `;
    }
}

customElements.define('room-form', RoomForm);
