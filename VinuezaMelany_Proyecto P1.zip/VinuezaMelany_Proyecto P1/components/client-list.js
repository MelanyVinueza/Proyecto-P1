class ClientList extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.container = document.createElement('div');
        this.styleElement = document.createElement('style');
        this.styleElement.textContent = `
            /* Estilo de la tabla */
           table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 20px 0;
                    background-color: #f9f9f9;
                    border-radius: 8px;
                }
            th, td {
                padding: 12px;
                border: 1px solid #ddd;
            }
            th {
                 background-color: #4CAF50;
                color: white;
                text-align: center;
            }
             tr:nth-child(even) {
                    background-color: #f2f2f2;
                }
                tr:hover {
                    background-color: #ddd;
                }
            /* Estilo de los botones */
            .actions button {
                margin: 0 5px;
                padding: 8px 16px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 14px;
                transition: background-color 0.3s;
            }
            .btn-update {
                background-color: #4CAF50;
                color: white;
                border: none;
            }
            .btn-update:hover {
                background-color: #45a049;
            }
            .btn-delete {
                background-color: #f44336;
                color: white;
                border: none;
            }
            .btn-delete:hover {
                background-color: #d32f2f;
            }
            .btn-create {
                background-color: #007BFF;
                color: white;
                border: none;
            }
            .btn-create:hover {
                background-color: #0056b3;
            }
            /* Estilo de los mensajes de error y vacíos */
            .error-alert {
                color: red;
                font-weight: bold;
                text-align: center;
                margin: 20px 0;
            }
            .empty-alert {
                color: gray;
                font-style: italic;
                text-align: center;
            }
        `;
        this.shadowRoot.appendChild(this.styleElement);
        this.shadowRoot.appendChild(this.container);
    }

    connectedCallback() {
        const apiUrl = 'http://127.0.0.1:3000/clientes';
        this.fetchData(apiUrl);
    }

    fetchData = async (url) => {
        try {
            const response = await fetch(url);
            const data = await response.json();
            this.render(data || []);
        } catch (error) {
            console.error("Error con la API", error);
            this.container.innerHTML = `<p class="error-alert">Error al cargar clientes</p>`;
        }
    };

    render = (clientes) => {
        if (clientes.length === 0) {
            this.container.innerHTML = `<p class="empty-alert">No hay clientes registrados</p>`;
            return;
        }

        let tableHTML = `
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Teléfono</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
        `;

        clientes.forEach((cliente) => {
            tableHTML += `
                <tr>
                    <td>${cliente.id_cliente}</td>
                    <td>${cliente.nombre}</td>
                    <td>${cliente.correo}</td>
                    <td>${cliente.telefono}</td>
                    <td class="actions">
                        <button class="btn-update" data-id="${cliente.id_cliente}" data-info='${JSON.stringify(cliente)}'>Actualizar</button>
                        <button class="btn-delete" data-id="${cliente.id_cliente}">Eliminar</button>
                        <button class="btn-create" data-id="${cliente.id_cliente}">Crear</button>
                    </td>
                </tr>
            `;
        });

        tableHTML += `</tbody></table>`;
        this.container.innerHTML = tableHTML;
    };

    handleDelete = async (id) => {
        if (confirm(`¿Estás seguro de eliminar el cliente con ID: ${id}?`)) {
            try {
                const response = await fetch(`http://127.0.0.1:3000/clientes/${id}`, { method: 'DELETE' });
                if (response.ok) {
                    alert('Cliente eliminado con éxito');
                    this.fetchData('http://127.0.0.1:3000/clientes');
                } else {
                    alert('Error al eliminar cliente');
                }
            } catch (error) {
                console.error("Error al eliminar cliente", error);
                alert('Error con la conexión a la API');
            }
        }
    };
}

window.customElements.define('client-list', ClientList);
