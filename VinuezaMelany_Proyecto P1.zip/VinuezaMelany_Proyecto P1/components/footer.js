class footer extends HTMLElement {
    constructor() {
        super();
        const shadow = this.attachShadow({ mode: 'open' });
        shadow.innerHTML = `
            <style>
                footer {
                    background: #2c3e50; /* Fondo oscuro */
                    color: white;
                    text-align: center;
                    padding: 1rem 0; /* Más espacio arriba y abajo */
                    margin: 0; /* Elimina márgenes */
                    position: fixed;
                    bottom: 0;
                    left: 0;
                    right: 0;
                    width: 100%;
                    font-family: 'Times New Roman', serif;
                }

                footer p {
                    margin: 0;
                    font-size: 16px;
                }

                footer a {
                    color: #f39c12; /* Color dorado */
                    text-decoration: none;
                }

                footer a:hover {
                    text-decoration: underline;
                }
            </style>
            <footer>
                <p>&copy; 2024 Mi Aplicación Web | <a href="#">Política de privacidad</a> | <a href="#">Términos y condiciones</a></p>
            </footer>
        `;
    }
}

customElements.define('app-footer', footer);
