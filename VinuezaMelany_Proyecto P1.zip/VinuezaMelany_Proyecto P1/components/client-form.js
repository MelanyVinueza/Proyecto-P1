class ClientForm extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.container = document.createElement("div");
        this.styleElement = document.createElement("style");
        this.styleElement.textContent = `
            /* Estilo del contenedor del formulario */
            .form-container {
                margin: 20px;
                padding: 20px;
                background: linear-gradient(
                    to right, 
                    rgba(255, 204, 153, 0.979),
                    rgba(255, 182, 193, 0.979),
                    rgba(173, 216, 230, 0.979)
                );
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                max-width: 500px;
                margin: 20px auto;
            }
            .form-container h2 {
                text-align: center;
                margin-bottom: 20px;
            }
            /* Estilo de las etiquetas y campos del formulario */
            .form-container label {
                display: block;
                margin: 10px 0 5px;
                font-size: 16px;
                color: #333;
            }
            .form-container input, .form-container button {
                width: 100%;
                padding: 10px;
                margin: 5px 0;
                font-size: 16px;
                border-radius: 4px;
                border: 1px solid #ccc;
                box-sizing: border-box;
            }
            .form-container input:focus {
                border-color: #007BFF;
                outline: none;
                box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
            }
            .form-container button {
                background-color: #4CAF50;
                color: white;
                cursor: pointer;
                border: none;
                transition: background-color 0.3s;
            }
            .form-container button:hover {
                background-color: #45a049;
            }
            /* Estilo de los mensajes de error */
            .error-alert {
                color: red;
                font-weight: bold;
                text-align: center;
                margin: 20px 0;
            }
        `;
        this.shadowRoot.appendChild(this.styleElement);
        this.shadowRoot.appendChild(this.container);
        this.isUpdating = false; // Bandera para diferenciar entre crear y actualizar
        this.currentClientId = null; // ID del cliente a actualizar
    }

    connectedCallback() {
        this.render();
        this.addEventListener('update-client', this.handleUpdate);
    }

    render = () => {
        this.container.innerHTML = `
            <div class="form-container">
                <h2>${this.isUpdating ? 'Actualizar Cliente' : 'Registrar Cliente'}</h2>
                <form id="client-form">
                    <label for="nombre">Nombre</label>
                    <input type="text" id="nombre" required>
                    <label for="correo">Correo Electrónico</label>
                    <input type="email" id="correo" required>
                    <label for="telefono">Teléfono</label>
                    <input type="text" id="telefono" required>
                    <button type="submit">${this.isUpdating ? 'Actualizar' : 'Registrar'}</button>
                </form>
            </div>
        `;
        this.shadowRoot.querySelector('#client-form').addEventListener('submit', this.handleSubmit);
    };

    handleSubmit = async (event) => {
        event.preventDefault();
        const nombre = this.shadowRoot.querySelector('#nombre').value;
        const correo = this.shadowRoot.querySelector('#correo').value;
        const telefono = this.shadowRoot.querySelector('#telefono').value;

        const url = this.isUpdating
            ? `http://127.0.0.1:3000/clientes/${this.currentClientId}`
            : 'http://127.0.0.1:3000/clientes';

        const method = this.isUpdating ? 'PUT' : 'POST';

        try {
            const response = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nombre, correo, telefono }),
            });
            if (response.ok) {
                alert(this.isUpdating ? 'Cliente actualizado con éxito' : 'Cliente registrado');
                this.dispatchEvent(new Event('refresh-list'));
                this.isUpdating = false;
                this.currentClientId = null;
                this.render();
            } else {
                alert('Error al procesar la solicitud');
            }
        } catch (error) {
            console.error("Error al enviar datos", error);
        }
    };

    handleUpdate = (event) => {
        const { id_cliente, nombre, correo, telefono } = event.detail;
        this.shadowRoot.querySelector('#nombre').value = nombre;
        this.shadowRoot.querySelector('#correo').value = correo;
        this.shadowRoot.querySelector('#telefono').value = telefono;
        this.isUpdating = true;
        this.currentClientId = id_cliente;
        this.render();
    };
}

window.customElements.define('client-form', ClientForm);
