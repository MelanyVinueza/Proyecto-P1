class RoomList extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        this.render();
        this.fetchRooms();
    }

    async fetchRooms() {
        try {
            const response = await fetch('http://localhost:3000/habitaciones/');
            const rooms = await response.json();
            this.updateRoomList(rooms);
        } catch (error) {
            console.error('Error al obtener habitaciones:', error);
        }
    }

    updateRoomList(rooms) {
        const roomList = this.shadowRoot.querySelector('#room-list');
        roomList.innerHTML = '';

        if (rooms.length === 0) {
            roomList.innerHTML = `<tr><td colspan="4">No hay habitaciones disponibles.</td></tr>`;
            return;
        }

        rooms.forEach(room => {
            const roomItem = document.createElement('tr');
            roomItem.innerHTML = `
                <td>${room.tipo}</td>
                <td>$${room.precio_noche}</td>
                <td>
                    <button class="update-button" data-id="${room.id_habitacion}">Actualizar</button>
                    <button class="delete-button" data-id="${room.id_habitacion}">Eliminar</button>
                </td>
            `;
            roomList.appendChild(roomItem);
        });

        // Agregar eventos para eliminar habitación
        const deleteButtons = this.shadowRoot.querySelectorAll('.delete-button');
        deleteButtons.forEach(button => {
            button.addEventListener('click', (e) => this.deleteRoom(e.target.dataset.id));
        });

        // Agregar eventos para actualizar habitación
        const updateButtons = this.shadowRoot.querySelectorAll('.update-button');
        updateButtons.forEach(button => {
            button.addEventListener('click', (e) => this.updateRoom(e.target.dataset.id));
        });
    }

    async deleteRoom(id) {
        const confirmDelete = confirm('¿Estás seguro de eliminar esta habitación?');
        if (!confirmDelete) return;

        try {
            const response = await fetch(`http://localhost:3000/habitaciones/${id}`, {
                method: 'DELETE',
            });

            if (response.ok) {
                alert('Habitación eliminada exitosamente.');
                this.fetchRooms(); // Actualizar la lista de habitaciones
            } else {
                alert('Error al eliminar la habitación.');
            }
        } catch (error) {
            console.error('Error al eliminar habitación:', error);
        }
    }

    updateRoom(id) {
        // Redirigir al formulario de actualización con el ID de la habitación
        window.location.href = `/actualizar-habitacion.html?id=${id}`;
    }

    render() {
        this.shadowRoot.innerHTML = `
            <style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 20px 0;
                    background-color: #f9f9f9;
                    border-radius: 8px;
                }
                th, td {
                    padding: 12px;
                    text-align: left;
                    border-bottom: 1px solid #ddd;
                }
                th {
                    background-color: #4CAF50;
                    color: white;
                    font-size: 16px;
                }
                tr:nth-child(even) {
                    background-color: #f2f2f2;
                }
                tr:hover {
                    background-color: #ddd;
                }
                button {
                    padding: 8px 16px;
                    font-size: 14px;
                    border-radius: 4px;
                    cursor: pointer;
                    margin: 5px;
                }
                .update-button {
                    background-color: #4CAF50;
                    color: white;
                    border: none;
                }
                .update-button:hover {
                    background-color: #45a049;
                }
                .delete-button {
                    background-color: #f44336;
                    color: white;
                    border: none;
                }
                .delete-button:hover {
                    background-color: #d32f2f;
                }
                .create-button {
                    background-color: #007BFF;
                    color: white;
                    border: none;
                    padding: 12px 20px;
                    font-size: 16px;
                    margin-top: 20px;
                    border-radius: 4px;
                }
                .create-button:hover {
                    background-color: #0056b3;
                }
                h2 {
                    text-align: center;
                    font-size: 24px;
                    color: #333;
                    margin-bottom: 20px;
                }
                .actions {
                    text-align: center;
                }
            </style>
            <h2>Lista de Habitaciones</h2>
            <table>
                <thead>
                    <tr>
                        <th>Tipo de Habitación</th>
                        <th>Precio por Noche</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="room-list">
                    <!-- Aquí se llenarán los datos -->
                </tbody>
            </table>
            <div class="actions">
                <button class="create-button" onclick="window.location.href='/crear-habitacion.html'">Crear nueva habitación</button>
            </div>
        `;
    }
}

customElements.define('room-list', RoomList);
