class NavBar extends HTMLElement {
    constructor() {
        super();

        const navContainer = document.createElement("div");
        navContainer.classList.add("container-nav");

        // Definir las opciones del menú con sus enlaces correspondientes
        const menuOptions = [
            { texto: "Home", enlace: "index.html" },
            { texto: "Clientes", enlace: "clientes.html" },
            { texto: "Habitaciones", enlace: "habitaciones.html" },
            { texto: "Reservas", enlace: "reservas.html" },
        ];

        // Crear la lista de opciones del menú
        const ul = document.createElement("ul");

        menuOptions.forEach(op => {
            const listItem = document.createElement("li");
            listItem.classList.add("menu-item");

            // Crear el enlace para cada opción
            const link = document.createElement("a");
            link.href = op.enlace;
            link.textContent = op.texto;

            listItem.appendChild(link);
            ul.appendChild(listItem);
        });

        // Crear un slot para contenido personalizado
        const slot = document.createElement("slot");
        slot.name = "menu"; // Slot para permitir personalizar el contenido

        // Añadir la lista de opciones al contenedor de navegación
        navContainer.appendChild(ul);
        navContainer.appendChild(slot);

        // Añadir estilos al Shadow DOM
        const style = document.createElement("style");
        style.textContent = `
            .container-nav {
                background-color: #fff;
                padding: 10px 0;
                text-align: center;
                position: relative;
                background-image: url('https://www.example.com/background.jpg'); /* Fondo del navbar */
                background-size: cover;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2); /* Sombra ligera */
                z-index: 10;
            }

            .container-nav ul {
                list-style: none;
                padding: 0;
                margin: 0;
                display: flex;
                justify-content: center;
                gap: 30px;
                position: relative;
                z-index: 5;
            }

            .menu-item {
                display: inline-flex;
                align-items: center;
                font-size: 20px;
            }

            .container-nav a {
                color: black;
                text-decoration: none;
                font-size: 18px;
                font-family: "Times New Roman", serif;
                text-transform: uppercase; /* Mayúsculas para los enlaces */
                transition: color 0.3s ease;
            }

            .container-nav a:hover {
                color: #B23A62; /* Color rosa oscuro al pasar el cursor */
            }

            /* Estilos responsivos */
            @media (max-width: 1024px) {
                .container-nav ul {
                    gap: 20px;
                }

                .menu-item {
                    font-size: 18px;
                }

                .container-nav a {
                    font-size: 16px;
                }
            }

            @media (max-width: 768px) {
                .container-nav ul {
                    flex-direction: column;
                    gap: 15px; /* Reducir el espacio entre los enlaces */
                }

                .menu-item {
                    margin: 10px 0;
                    font-size: 18px;
                }

                .container-nav a {
                    font-size: 16px;
                }

                .container-nav {
                    padding: 5px 0;
                }
            }

            @media (max-width: 480px) {
                .container-nav ul {
                    gap: 10px;
                }

                .menu-item {
                    font-size: 16px;
                }

                .container-nav a {
                    font-size: 14px;
                }
            }
        `;
        this.attachShadow({ mode: 'open' }).appendChild(style);
        this.shadowRoot.appendChild(navContainer);
    }
}

// Definir el nuevo elemento personalizado
window.customElements.define("nav-bar", NavBar);
