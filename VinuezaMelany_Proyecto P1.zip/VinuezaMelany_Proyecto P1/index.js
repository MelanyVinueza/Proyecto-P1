import express from 'express';
import bodyParser from 'body-parser';
import mysql from 'mysql2';
import cors from 'cors';

// Configuración de la aplicación y puerto
const app = express();
const port = 3000;

app.use(cors({ origin: '*' })); // Permitir todas las conexiones
app.use(bodyParser.json());

// Iniciar el servidor
app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
});

// Ruta de inicio
app.get("/", (req, res) => {
    res.send("Bienvenidos a mi API de Reservas de Hotel");
});

// Configuración de la base de datos
const db = mysql.createConnection({
    host: '127.0.0.1',
    user: 'root',
    password: '12345',
    database: 'SistemaReservas'
});

// Conexión a MySQL
db.connect((error) => {
    if (error) {
        console.log("Error al conectar a la base de datos");
        return;
    } else {
        console.log("Conexión exitosa a la base de datos");
    }
});

// **RUTAS Y CONTROLADORES**

/* CLIENTES */
// Obtener todos los clientes
app.get("/clientes/", (req, res) => {
    const query = 'SELECT * FROM Clientes';
    db.query(query, (error, results) => {
        if (error) {
            res.status(500).send('Error al obtener los clientes');
            return;
        }
        res.status(200).json(results);
    });
});

// Crear un cliente
app.post("/clientes/", (req, res) => {
    const { nombre, correo, telefono } = req.body;
    if (!nombre || !correo || !telefono) {
        res.status(400).send('Faltan datos para registrar el cliente');
        return;
    }
    const query = 'INSERT INTO Clientes (nombre, correo, telefono) VALUES (?, ?, ?)';
    db.query(query, [nombre, correo, telefono], (error, results) => {
        if (error) {
            res.status(500).send('Error al registrar el cliente');
            return;
        }
        res.status(201).json('Cliente registrado exitosamente');
    });
});

// Actualizar un cliente
app.put("/clientes/:id_cliente", (req, res) => {
    const { id_cliente } = req.params;
    const { nombre, correo, telefono } = req.body;

    if (!nombre || !correo || !telefono) {
        res.status(400).send('Faltan datos para actualizar el cliente');
        return;
    }

    const query = 'UPDATE Clientes SET nombre = ?, correo = ?, telefono = ? WHERE id_cliente = ?';
    db.query(query, [nombre, correo, telefono, id_cliente], (error, results) => {
        if (error) {
            res.status(500).send('Error al actualizar el cliente');
            return;
        }
        if (results.affectedRows === 0) {
            res.status(404).send('No existe el cliente');
            return;
        }
        res.status(200).json('Cliente actualizado exitosamente');
    });
});

// Eliminar un cliente
app.delete("/clientes/:id_cliente", (req, res) => {
    const { id_cliente } = req.params;
    const query = 'DELETE FROM Clientes WHERE id_cliente = ?';
    db.query(query, [id_cliente], (error, results) => {
        if (error) {
            res.status(500).send('Error al eliminar el cliente');
            return;
        }
        if (results.affectedRows === 0) {
            res.status(404).send('No existe el cliente');
            return;
        }
        res.status(200).json('Cliente eliminado exitosamente');
    });
});

/* HABITACIONES */
// Obtener todas las habitaciones
app.get("/habitaciones/", (req, res) => {
    const query = 'SELECT * FROM Habitaciones';
    db.query(query, (error, results) => {
        if (error) {
            res.status(500).send('Error al obtener las habitaciones');
            return;
        }
        res.status(200).json(results);
    });
});

// Crear una habitación
app.post("/habitaciones/", (req, res) => {
    const { tipo, precio_noche } = req.body;

    if (!tipo || !precio_noche) {
        res.status(400).send('Faltan datos para registrar la habitación');
        return;
    }

    const query = 'INSERT INTO Habitaciones (tipo, precio_noche) VALUES (?, ?)';
    db.query(query, [tipo, precio_noche], (error, results) => {
        if (error) {
            res.status(500).send('Error al registrar la habitación');
            return;
        }
        res.status(201).json('Habitación registrada exitosamente');
    });
});

// Actualizar una habitación
app.put("/habitaciones/:id_habitacion", (req, res) => {
    const { id_habitacion } = req.params;
    const { tipo, precio_noche } = req.body;

    if (!tipo || !precio_noche) {
        res.status(400).send('Faltan datos para actualizar la habitación');
        return;
    }

    const query = 'UPDATE Habitaciones SET tipo = ?, precio_noche = ? WHERE id_habitacion = ?';
    db.query(query, [tipo, precio_noche, id_habitacion], (error, results) => {
        if (error) {
            res.status(500).send('Error al actualizar la habitación');
            return;
        }
        if (results.affectedRows === 0) {
            res.status(404).send('No existe la habitación');
            return;
        }
        res.status(200).json('Habitación actualizada exitosamente');
    });
});

// Eliminar una habitación
app.delete("/habitaciones/:id_habitacion", (req, res) => {
    const { id_habitacion } = req.params;

    const query = 'DELETE FROM Habitaciones WHERE id_habitacion = ?';
    db.query(query, [id_habitacion], (error, results) => {
        if (error) {
            res.status(500).send('Error al eliminar la habitación');
            return;
        }
        if (results.affectedRows === 0) {
            res.status(404).send('No existe la habitación');
            return;
        }
        res.status(200).json('Habitación eliminada exitosamente');
    });
});

/* RESERVAS */
// Obtener todas las reservas con información relacionada
app.get("/reservas/", (req, res) => {
    const query = `
    SELECT 
        r.id_reserva,
        c.nombre AS cliente,
        h.tipo AS habitacion,
        r.fecha_inicio,
        r.fecha_fin
    FROM Reservas r
    INNER JOIN Clientes c ON r.id_cliente = c.id_cliente
    INNER JOIN Habitaciones h ON r.id_habitacion = h.id_habitacion
    `;
    db.query(query, (error, results) => {
        if (error) {
            res.status(500).send('Error al obtener las reservas');
            return;
        }
        res.status(200).json(results);
    });
});
